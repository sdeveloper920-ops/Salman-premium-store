# EarnTaskHubBot — GitHub + Render starter

বাংলা নির্দেশনা:

## ১) Telegram bot token
1. Telegram-এ `@BotFather` খুলে `/newbot` দিয়ে bot তৈরি করো।
2. পাওয়া token গোপন রাখবে। GitHub-এ কখনো token লিখবে না।
3. bot username-টি `BOT_USERNAME` environment variable-এ দেবে (`@` ছাড়া)।

## ২) PostgreSQL database
Render PostgreSQL, Neon বা Supabase থেকে PostgreSQL database তৈরি করো।
তার connection string `DATABASE_URL` নামে Render Environment-এ বসাও।
Connection string-এ password আছে—এটি কাউকে পাঠাবে না।

## ৩) Admin ID
Telegram-এ `@userinfobot` দিয়ে নিজের numeric Telegram ID জেনে `ADMIN_ID`-তে বসাও।
`ADMIN_ID` না দিলে admin command কাজ করবে না।

## ৪) GitHub
এই ZIP extract করে সব ফাইল একটি নতুন GitHub repository-তে upload করো।

## ৫) Render deploy
1. Render dashboard → New → Web Service → GitHub repository connect করো।
2. Build Command: `pip install -r requirements.txt`
3. Start Command: `python bot.py`
4. Environment Variables যোগ করো:
   - `BOT_TOKEN`
   - `ADMIN_ID`
   - `BOT_USERNAME`
   - `DATABASE_URL`
   - `REFERRAL_BONUS` (optional, default 5)
   - `MIN_WITHDRAW` (optional, default 200)
   - `CURRENCY` (optional, default ৳)
5. Deploy শেষে Render URL খুলে `{"status":"ok"...}` দেখলে web health endpoint চলছে।
6. Telegram bot-এ `/start` পাঠাও।

## User features
- Balance, profile, task list, referral link, deposit/withdraw request, transaction history
- Task claim creates a pending claim; user must contact admin with proof. Admin manually verifies proof outside the bot in this starter.

## Admin commands
- `/admin` — command list
- `/addtask Title | Description | Reward`
- `/approve REQUEST_ID` — approve pending deposit/withdraw request
- `/reject REQUEST_ID` — reject request (withdraw amount is refunded)
- `/credit USER_ID AMOUNT` — manually add balance
- `/users` — total users

## Important notes
- This is a starter MVP, not a production-ready financial platform.
- Withdraw requests reserve/deduct the user's balance until approved; rejection refunds it.
- Deposit approval adds balance. Verify every payment manually before approving.
- Referral bonus is credited automatically when a new user starts with a valid referral link. Add anti-abuse checks before public launch.
- Task claims are recorded as pending but do not automatically pay rewards. Verify work and credit the user using `/credit`.
- Add terms, privacy policy, fraud prevention, rate limits, backups, and proper support before launch.
- Render free web services may sleep when idle; polling bots may become temporarily unavailable. For reliable 24/7 operation use an always-on worker/paid service or another suitable host.
- Keep database credentials and bot token private. If leaked, rotate them immediately with BotFather / database provider.
