import os
import logging
import threading
from contextlib import contextmanager
from flask import Flask, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, filters
)

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
DATABASE_URL = os.environ["DATABASE_URL"]
BOT_USERNAME = os.getenv("BOT_USERNAME", "").lstrip("@")
CURRENCY = os.getenv("CURRENCY", "৳")
REFERRAL_BONUS = float(os.getenv("REFERRAL_BONUS", "5"))
MIN_WITHDRAW = float(os.getenv("MIN_WITHDRAW", "200"))

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO
)
log = logging.getLogger("EarnTaskHubBot")

app = Flask(__name__)

def db():
    return psycopg2.connect(DATABASE_URL, sslmode="require", cursor_factory=RealDictCursor)

def init_db():
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id BIGINT PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    balance NUMERIC(12,2) NOT NULL DEFAULT 0,
                    referred_by BIGINT,
                    joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                );
                CREATE TABLE IF NOT EXISTS tasks (
                    id SERIAL PRIMARY KEY,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    reward NUMERIC(12,2) NOT NULL,
                    active BOOLEAN NOT NULL DEFAULT TRUE
                );
                CREATE TABLE IF NOT EXISTS task_claims (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    task_id INTEGER NOT NULL REFERENCES tasks(id),
                    status TEXT NOT NULL DEFAULT 'pending',
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    UNIQUE(user_id, task_id)
                );
                CREATE TABLE IF NOT EXISTS transactions (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    kind TEXT NOT NULL,
                    amount NUMERIC(12,2) NOT NULL,
                    details TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                );
            """)
        conn.commit()

def money(value):
    return f"{CURRENCY}{float(value):.2f}"

def is_admin(update):
    return update.effective_user and update.effective_user.id == ADMIN_ID

def main_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💰 Balance", callback_data="balance"),
         InlineKeyboardButton("✅ Tasks", callback_data="tasks")],
        [InlineKeyboardButton("👥 Referral", callback_data="referral"),
         InlineKeyboardButton("💳 Withdraw", callback_data="withdraw")],
        [InlineKeyboardButton("📥 Deposit", callback_data="deposit"),
         InlineKeyboardButton("📜 History", callback_data="history")],
        [InlineKeyboardButton("👤 Profile", callback_data="profile"),
         InlineKeyboardButton("ℹ️ Help", callback_data="help")]
    ])

def get_user(user_id):
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM users WHERE user_id=%s", (user_id,))
            return cur.fetchone()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    referrer = None
    if context.args:
        try:
            candidate = int(context.args[0])
            if candidate != user.id:
                referrer = candidate
        except ValueError:
            pass

    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT user_id FROM users WHERE user_id=%s", (user.id,))
            exists = cur.fetchone()
            if not exists:
                cur.execute(
                    "INSERT INTO users(user_id, username, full_name, referred_by) VALUES(%s,%s,%s,%s)",
                    (user.id, user.username or "", user.full_name, referrer)
                )
                if referrer:
                    cur.execute("SELECT user_id FROM users WHERE user_id=%s", (referrer,))
                    if cur.fetchone():
                        cur.execute(
                            "UPDATE users SET balance=balance+%s WHERE user_id=%s",
                            (REFERRAL_BONUS, referrer)
                        )
                        cur.execute(
                            """INSERT INTO transactions(user_id,kind,amount,details,status)
                               VALUES(%s,'referral',%s,%s,'approved')""",
                            (referrer, REFERRAL_BONUS, f"Referral joined: {user.id}")
                        )
        conn.commit()

    await update.message.reply_text(
        f"স্বাগতম, {user.first_name}! 👋\n\nEarnTaskHub-এ স্বাগতম। নিচের মেনু থেকে অপশন বেছে নাও।",
        reply_markup=main_keyboard()
    )

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    data = q.data

    if data == "home":
        await q.edit_message_text("🏠 Main Menu", reply_markup=main_keyboard())
    elif data == "balance":
        u = get_user(uid)
        await q.edit_message_text(f"💰 তোমার ব্যালেন্স: *{money(u['balance'])}*",
                                  parse_mode="Markdown", reply_markup=main_keyboard())
    elif data == "profile":
        u = get_user(uid)
        await q.edit_message_text(
            f"👤 *Profile*\nName: {u['full_name']}\nUser ID: `{uid}`\nBalance: {money(u['balance'])}",
            parse_mode="Markdown", reply_markup=main_keyboard()
        )
    elif data == "tasks":
        with db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM tasks WHERE active=TRUE ORDER BY id DESC")
                tasks = cur.fetchall()
        if not tasks:
            await q.edit_message_text("এখন কোনো active task নেই।", reply_markup=main_keyboard())
            return
        buttons = [[InlineKeyboardButton(
            f"#{t['id']} {t['title']} — {money(t['reward'])}",
            callback_data=f"task_{t['id']}"
        )] for t in tasks]
        buttons.append([InlineKeyboardButton("⬅️ Menu", callback_data="home")])
        await q.edit_message_text("✅ একটি Task বেছে নাও:", reply_markup=InlineKeyboardMarkup(buttons))
    elif data.startswith("task_"):
        task_id = int(data.split("_", 1)[1])
        with db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM tasks WHERE id=%s AND active=TRUE", (task_id,))
                task = cur.fetchone()
                if not task:
                    await q.edit_message_text("Task পাওয়া যায়নি।", reply_markup=main_keyboard())
                    return
                cur.execute(
                    """INSERT INTO task_claims(user_id,task_id,status) VALUES(%s,%s,'pending')
                       ON CONFLICT(user_id,task_id) DO NOTHING""", (uid, task_id)
                )
            conn.commit()
        await q.edit_message_text(
            f"📌 *{task['title']}*\n{task['description']}\n\nReward: {money(task['reward'])}\n\n"
            "কাজ শেষ করে প্রমাণ/স্ক্রিনশট Admin-কে পাঠাও। যাচাইয়ের পর reward যোগ হবে।",
            parse_mode="Markdown", reply_markup=main_keyboard()
        )
    elif data == "referral":
        link = f"https://t.me/{BOT_USERNAME}?start={uid}" if BOT_USERNAME else f"/start {uid}"
        await q.edit_message_text(
            f"👥 *Referral Program*\nপ্রতি valid নতুন referral-এ bonus: {money(REFERRAL_BONUS)}\n\n"
            f"তোমার referral link:\n`{link}`",
            parse_mode="Markdown", reply_markup=main_keyboard()
        )
    elif data == "withdraw":
        context.user_data["awaiting"] = "withdraw"
        await q.edit_message_text(
            f"💳 Withdraw request দিতে নিচের format-এ পাঠাও:\n`Amount | Method | Account Number`\n"
            f"Minimum: {money(MIN_WITHDRAW)}",
            parse_mode="Markdown"
        )
    elif data == "deposit":
        context.user_data["awaiting"] = "deposit"
        await q.edit_message_text(
            "📥 Deposit request দিতে পাঠাও:\n`Amount | Payment Method | Transaction ID`\n"
            "Admin যাচাই করে balance যোগ করবেন।",
            parse_mode="Markdown"
        )
    elif data == "history":
        with db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT kind,amount,status,details FROM transactions WHERE user_id=%s ORDER BY id DESC LIMIT 10",
                    (uid,)
                )
                rows = cur.fetchall()
        if not rows:
            msg = "এখনো কোনো transaction নেই।"
        else:
            msg = "📜 *শেষ ১০টি Transaction*\n\n" + "\n".join(
                f"• {r['kind']} | {money(r['amount'])} | {r['status']}" for r in rows
            )
        await q.edit_message_text(msg, parse_mode="Markdown", reply_markup=main_keyboard())
    elif data == "help":
        await q.edit_message_text(
            "ℹ️ Help\nTask করতে Tasks বেছে নাও। Deposit/Withdraw request Admin যাচাই করবেন। "
            "কোনো সমস্যা হলে Admin-এর সাথে যোগাযোগ করো।",
            reply_markup=main_keyboard()
        )

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    mode = context.user_data.get("awaiting")
    if not mode:
        await update.message.reply_text("মেনু ব্যবহার করতে /start চাপো।", reply_markup=main_keyboard())
        return
    parts = [p.strip() for p in update.message.text.split("|")]
    if len(parts) != 3:
        await update.message.reply_text("সঠিক format ব্যবহার করো: Amount | Method | Account/Transaction ID")
        return
    try:
        amount = float(parts[0])
        if amount <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("সঠিক Amount লিখো।")
        return

    uid = update.effective_user.id
    if mode == "withdraw":
        if amount < MIN_WITHDRAW:
            await update.message.reply_text(f"Minimum withdraw {money(MIN_WITHDRAW)}।")
            return
        u = get_user(uid)
        if float(u["balance"]) < amount:
            await update.message.reply_text("তোমার পর্যাপ্ত balance নেই।")
            return
        kind = "withdraw"
    else:
        kind = "deposit"

    details = f"{parts[1]} | {parts[2]}"
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO transactions(user_id,kind,amount,details,status) VALUES(%s,%s,%s,%s,'pending') RETURNING id",
                (uid, kind, amount, details)
            )
            txid = cur.fetchone()["id"]
            if kind == "withdraw":
                cur.execute("UPDATE users SET balance=balance-%s WHERE user_id=%s", (amount, uid))
        conn.commit()
    context.user_data.pop("awaiting", None)
    await update.message.reply_text(f"✅ Request জমা হয়েছে। Request ID: {txid}", reply_markup=main_keyboard())
    if ADMIN_ID:
        try:
            await context.bot.send_message(
                ADMIN_ID,
                f"🔔 নতুন {kind} request\nID: {txid}\nUser: {uid}\nAmount: {money(amount)}\nDetails: {details}\n\n"
                f"Approve: /approve {txid}\nReject: /reject {txid}"
            )
        except Exception:
            log.exception("Could not notify admin")

async def admin_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return
    await update.message.reply_text(
        "Admin commands:\n"
        "/addtask Title | Description | Reward\n"
        "/approve REQUEST_ID\n/reject REQUEST_ID\n"
        "/credit USER_ID AMOUNT\n/users\n"
    )

async def addtask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return
    raw = update.message.text.partition(" ")[2]
    parts = [p.strip() for p in raw.split("|")]
    if len(parts) != 3:
        await update.message.reply_text("Format: /addtask Title | Description | Reward")
        return
    try:
        reward = float(parts[2])
        if reward <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("Reward অবশ্যই positive number হতে হবে।")
        return
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO tasks(title,description,reward) VALUES(%s,%s,%s) RETURNING id",
                        (parts[0], parts[1], reward))
            tid = cur.fetchone()["id"]
        conn.commit()
    await update.message.reply_text(f"✅ Task added. ID: {tid}")

async def approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Usage: /approve REQUEST_ID")
        return
    txid = int(context.args[0])
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM transactions WHERE id=%s AND status='pending' FOR UPDATE", (txid,))
            tx = cur.fetchone()
            if not tx:
                await update.message.reply_text("Pending request পাওয়া যায়নি।")
                return
            if tx["kind"] == "deposit":
                cur.execute("UPDATE users SET balance=balance+%s WHERE user_id=%s", (tx["amount"], tx["user_id"]))
            cur.execute("UPDATE transactions SET status='approved' WHERE id=%s", (txid,))
        conn.commit()
    await update.message.reply_text(f"✅ Request {txid} approved.")
    try:
        await context.bot.send_message(tx["user_id"], f"✅ তোমার {tx['kind']} request approved হয়েছে: {money(tx['amount'])}")
    except Exception:
        pass

async def reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Usage: /reject REQUEST_ID")
        return
    txid = int(context.args[0])
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM transactions WHERE id=%s AND status='pending' FOR UPDATE", (txid,))
            tx = cur.fetchone()
            if not tx:
                await update.message.reply_text("Pending request পাওয়া যায়নি।")
                return
            if tx["kind"] == "withdraw":
                cur.execute("UPDATE users SET balance=balance+%s WHERE user_id=%s", (tx["amount"], tx["user_id"]))
            cur.execute("UPDATE transactions SET status='rejected' WHERE id=%s", (txid,))
        conn.commit()
    await update.message.reply_text(f"❌ Request {txid} rejected.")
    try:
        await context.bot.send_message(tx["user_id"], f"❌ তোমার {tx['kind']} request reject হয়েছে।")
    except Exception:
        pass

async def credit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return
    if len(context.args) != 2:
        await update.message.reply_text("Usage: /credit USER_ID AMOUNT")
        return
    try:
        uid, amount = int(context.args[0]), float(context.args[1])
        if amount <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("সঠিক User ID এবং positive amount দাও।")
        return
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("UPDATE users SET balance=balance+%s WHERE user_id=%s RETURNING user_id", (amount, uid))
            if not cur.fetchone():
                await update.message.reply_text("User পাওয়া যায়নি।")
                return
            cur.execute("INSERT INTO transactions(user_id,kind,amount,details,status) VALUES(%s,'admin_credit',%s,'Admin credit','approved')",
                        (uid, amount))
        conn.commit()
    await update.message.reply_text(f"✅ {money(amount)} added to {uid}.")

async def users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS n FROM users")
            count = cur.fetchone()["n"]
    await update.message.reply_text(f"👥 Total registered users: {count}")

@app.get("/")
def health():
    return jsonify({"status": "ok", "service": "EarnTaskHubBot"})

def run_web():
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "10000")))

def run_bot():
    init_db()
    application = Application.builder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("admin", admin_help))
    application.add_handler(CommandHandler("addtask", addtask))
    application.add_handler(CommandHandler("approve", approve))
    application.add_handler(CommandHandler("reject", reject))
    application.add_handler(CommandHandler("credit", credit))
    application.add_handler(CommandHandler("users", users))
    application.add_handler(CallbackQueryHandler(menu_callback))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    application.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    threading.Thread(target=run_bot, daemon=True).start()
    run_web()
